import * as THREE from "three";

let scene, camera, renderer, socket, myId = null, myYaw = 0;
let meMesh, playerMeshes = new Map(), zoneMesh;
let moveX = 0, moveZ = 0, joined = false;
let lastInput = 0;
const clock = new THREE.Clock();
const arenaSize = 80;

const lobby = document.getElementById("lobby");
const hud = document.getElementById("hud");
const connection = document.getElementById("connection");
const notice = document.getElementById("notice");

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x9ac5d8);
  scene.fog = new THREE.Fog(0x9ac5d8, 55, 130);

  camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 250);
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  document.body.appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xddeeff, 0x536044, 2));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2);
  sun.position.set(25, 50, 20);
  sun.castShadow = true;
  scene.add(sun);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(arenaSize, arenaSize),
    new THREE.MeshStandardMaterial({ color: 0x647d4c })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(arenaSize, 40, 0x526a43, 0x526a43);
  grid.position.y = 0.03;
  scene.add(grid);

  // Simple buildings and trees make a lightweight starter battleground.
  for (let i = 0; i < 24; i++) {
    const x = (Math.random() - .5) * 68;
    const z = (Math.random() - .5) * 68;
    if (Math.abs(x) < 7 && Math.abs(z) < 7) continue;
    if (i % 2 === 0) {
      const h = 2 + Math.random() * 3;
      const building = new THREE.Mesh(
        new THREE.BoxGeometry(3 + Math.random() * 2, h, 3 + Math.random() * 2),
        new THREE.MeshStandardMaterial({ color: 0x9b8a70 })
      );
      building.position.set(x, h / 2, z);
      building.castShadow = true;
      building.receiveShadow = true;
      scene.add(building);
    } else {
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(.18, .25, 1.5, 7),
        new THREE.MeshStandardMaterial({ color: 0x65452d })
      );
      trunk.position.set(x, .75, z);
      scene.add(trunk);
      const leaves = new THREE.Mesh(
        new THREE.ConeGeometry(1.2, 3, 7),
        new THREE.MeshStandardMaterial({ color: 0x285b36 })
      );
      leaves.position.set(x, 2.8, z);
      scene.add(leaves);
    }
  }

  zoneMesh = new THREE.Mesh(
    new THREE.RingGeometry(0.97, 1, 96),
    new THREE.MeshBasicMaterial({ color: 0x45bfff, side: THREE.DoubleSide })
  );
  zoneMesh.rotation.x = -Math.PI / 2;
  zoneMesh.position.y = .12;
  scene.add(zoneMesh);

  addEventListener("resize", () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });
}

function makePlayer(color) {
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(.42, .75, 4, 8),
    new THREE.MeshStandardMaterial({ color })
  );
  body.position.y = .95;
  body.castShadow = true;
  group.add(body);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(.28, 12, 10),
    new THREE.MeshStandardMaterial({ color: 0xe7b98d })
  );
  head.position.y = 1.72;
  group.add(head);

  const gun = new THREE.Mesh(
    new THREE.BoxGeometry(.16, .15, .9),
    new THREE.MeshStandardMaterial({ color: 0x24282c })
  );
  gun.position.set(.35, 1.15, -.45);
  group.add(gun);
  return group;
}

function connect() {
  const name = document.getElementById("playerName").value || "Player";
  const scheme = location.protocol === "https:" ? "wss:" : "ws:";
  socket = new WebSocket(`${scheme}//${location.host}/ws?name=${encodeURIComponent(name)}`);

  socket.onopen = () => {
    connection.textContent = "Connected. Joining arena...";
  };
  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === "welcome") {
      myId = data.id;
      joined = true;
      lobby.classList.add("hidden");
      hud.classList.remove("hidden");
      notice.textContent = "You joined the arena!";
      setTimeout(() => notice.textContent = "", 2500);
    } else if (data.type === "state") {
      updateWorld(data);
    } else if (data.type === "message") {
      notice.textContent = data.text;
      setTimeout(() => { if (notice.textContent === data.text) notice.textContent = ""; }, 2500);
    } else if (data.type === "hit") {
      if (data.target === myId) {
        document.getElementById("health").textContent = `Health: ${data.hp}`;
      }
    } else if (data.type === "error") {
      connection.textContent = data.message;
    }
  };
  socket.onclose = () => {
    if (joined) notice.textContent = "Disconnected. Refresh to reconnect.";
    else connection.textContent = "Could not connect. Try again.";
  };
  socket.onerror = () => connection.textContent = "Connection error.";
}

function updateWorld(data) {
  document.getElementById("players").textContent = `Players: ${data.count}`;
  document.getElementById("zone").textContent = `Safe zone: ${Math.round(data.zone.radius)}m`;
  zoneMesh.scale.set(data.zone.radius, data.zone.radius, 1);

  const seen = new Set();
  for (const p of data.players) {
    seen.add(p.id);
    let mesh = playerMeshes.get(p.id);
    if (!mesh) {
      mesh = makePlayer(p.id === myId ? 0x3478db : 0xc94b42);
      scene.add(mesh);
      playerMeshes.set(p.id, mesh);
    }
    mesh.position.set(p.x, 0, p.z);
    mesh.rotation.y = p.yaw;
    mesh.visible = p.alive;
    if (p.id === myId) {
      meMesh = mesh;
      document.getElementById("health").textContent = `Health: ${p.hp}`;
      document.getElementById("respawnBtn").classList.toggle("hidden", p.alive);
    }
  }
  for (const [id, mesh] of playerMeshes) {
    if (!seen.has(id)) {
      scene.remove(mesh);
      playerMeshes.delete(id);
    }
  }
}

function sendInput() {
  if (!socket || socket.readyState !== WebSocket.OPEN || !myId) return;
  const now = performance.now();
  if (now - lastInput < 50) return;
  lastInput = now;
  socket.send(JSON.stringify({ type: "input", x: moveX, z: moveZ, yaw: myYaw }));
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .05);
  if (meMesh) {
    const forward = new THREE.Vector3(Math.sin(myYaw), 0, -Math.cos(myYaw));
    const right = new THREE.Vector3(Math.cos(myYaw), 0, Math.sin(myYaw));
    const desired = meMesh.position.clone()
      .addScaledVector(right, moveX * 8 * dt)
      .addScaledVector(forward, -moveZ * 8 * dt);
    camera.position.lerp(new THREE.Vector3(desired.x, 7, desired.z + 10), .12);
    camera.lookAt(meMesh.position.x, 1, meMesh.position.z);
    sendInput();
  } else {
    camera.position.set(0, 25, 35);
    camera.lookAt(0, 0, 0);
  }
  renderer.render(scene, camera);
}

function setupControls() {
  const joystick = document.getElementById("joystick");
  const stick = document.getElementById("stick");
  let pointer = null;
  let center = {x: 0, y: 0};

  joystick.addEventListener("pointerdown", e => {
    pointer = e.pointerId;
    joystick.setPointerCapture(pointer);
    const r = joystick.getBoundingClientRect();
    center = {x: r.left + r.width / 2, y: r.top + r.height / 2};
    updateStick(e);
  });
  joystick.addEventListener("pointermove", e => { if (pointer === e.pointerId) updateStick(e); });
  function updateStick(e) {
    const dx = e.clientX - center.x;
    const dy = e.clientY - center.y;
    const max = 35;
    const x = Math.max(-max, Math.min(max, dx));
    const y = Math.max(-max, Math.min(max, dy));
    stick.style.transform = `translate(${x}px, ${y}px)`;
    moveX = x / max;
    moveZ = y / max;
    myYaw = Math.atan2(moveX, -moveZ);
  }
  function release(e) {
    if (pointer === e.pointerId) {
      pointer = null;
      moveX = 0; moveZ = 0;
      stick.style.transform = "translate(0,0)";
    }
  }
  joystick.addEventListener("pointerup", release);
  joystick.addEventListener("pointercancel", release);

  document.getElementById("fireBtn").addEventListener("pointerdown", e => {
    e.preventDefault();
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({type: "shoot"}));
    }
  });

  document.getElementById("respawnBtn").addEventListener("click", () => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({type: "respawn"}));
    }
  });

  document.getElementById("exitBtn").addEventListener("click", () => {
    if (socket) socket.close();
    location.reload();
  });

  // Desktop mouse controls: click the canvas to turn and fire.
  renderer.domElement.addEventListener("click", e => {
    if (e.clientX > innerWidth * .25 && socket?.readyState === WebSocket.OPEN) {
      myYaw = Math.atan2(e.clientX - innerWidth / 2, innerHeight / 2);
      socket.send(JSON.stringify({type: "shoot"}));
    }
  });
}

document.getElementById("joinBtn").addEventListener("click", () => {
  if (!scene) {
    createWorld();
    setupControls();
    animate();
  }
  connect();
});
