# Battle Arena 3D

A small original 3D multiplayer battle-arena prototype. It is inspired by the battle-royale genre and does not use PUBG assets or branding.

## Features in this starter
- Browser-based 3D arena using Three.js
- Python FastAPI backend
- WebSocket multiplayer state
- Player movement, simple directional shooting and health
- Gradually shrinking safe zone
- Mobile touch joystick and fire button
- Works in modern Android and desktop browsers

## Run locally
1. Install Python 3.10 or newer.
2. `pip install -r requirements.txt`
3. `uvicorn main:app --reload`
4. Open http://127.0.0.1:8000 in two browser tabs/devices on the same network (for another device, use your computer's LAN IP).

## Deploy to Render
- Push all files to a GitHub repository.
- In Render choose New > Web Service and connect the repository.
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- The included render.yaml can also be used as a Blueprint.

## Deploy to Railway
- Create a project and choose Deploy from GitHub Repo.
- Select this repository.
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Generate a public domain in Networking.

## Important prototype limitations
- This is a learning prototype, not a production-ready commercial battle royale.
- All clients connected to one server instance share one arena. The server stores active matches in memory; a restart clears the match.
- For reliable multiplayer, deploy one active server replica. Multiple replicas need shared state and matchmaking (for example Redis).
- Movement and hit detection are simplified. A production game needs stronger server-authoritative physics, anti-cheat, lag compensation, matchmaking, accounts, persistence, moderation, load testing, and optimized art/audio.
- The Three.js library is loaded from jsDelivr, so clients need internet access to load it.
- Android players can play in Chrome and add the page to their home screen. This is not yet a native Play Store APK.
