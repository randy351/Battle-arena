import asyncio
import json
import math
import os
import secrets
import time
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="Battle Arena Multiplayer Server")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

players = {}
connections = {}
started_at = time.monotonic()
WORLD_LIMIT = 40.0
TICK_RATE = 20
MAX_PLAYERS = 40

def safe_name(value):
    name = "".join(ch for ch in str(value or "Player") if ch.isalnum() or ch in " _-")[:16].strip()
    return name or "Player"

def public_state():
    elapsed = time.monotonic() - started_at
    # Safe zone slowly contracts from radius 35 to 12 over five minutes.
    zone_radius = max(12.0, 35.0 - elapsed * (23.0 / 300.0))
    return {
        "type": "state",
        "players": [
            {
                "id": p["id"], "name": p["name"], "x": round(p["x"], 2),
                "z": round(p["z"], 2), "yaw": round(p["yaw"], 3),
                "hp": p["hp"], "alive": p["alive"]
            } for p in players.values()
        ],
        "zone": {"x": 0, "z": 0, "radius": round(zone_radius, 2)},
        "count": len(players)
    }

async def broadcast(message):
    stale = []
    payload = json.dumps(message)
    for pid, ws in list(connections.items()):
        try:
            await ws.send_text(payload)
        except Exception:
            stale.append(pid)
    for pid in stale:
        connections.pop(pid, None)
        players.pop(pid, None)

async def game_loop():
    last = time.monotonic()
    while True:
        now = time.monotonic()
        dt = min(now - last, 0.1)
        last = now
        elapsed = now - started_at
        zone_radius = max(12.0, 35.0 - elapsed * (23.0 / 300.0))

        for p in list(players.values()):
            if not p["alive"]:
                if now >= p["respawn_at"]:
                    p["alive"] = True
                    p["hp"] = 100
                    p["x"] = secrets.choice([-12, -8, 8, 12]) + secrets.randbelow(50) / 10
                    p["z"] = secrets.choice([-12, -8, 8, 12]) + secrets.randbelow(50) / 10
                continue

            dx, dz = p["move"]
            length = math.hypot(dx, dz)
            if length > 1:
                dx, dz = dx / length, dz / length
            speed = 8.0
            p["x"] = max(-WORLD_LIMIT, min(WORLD_LIMIT, p["x"] + dx * speed * dt))
            p["z"] = max(-WORLD_LIMIT, min(WORLD_LIMIT, p["z"] + dz * speed * dt))

            if math.hypot(p["x"], p["z"]) > zone_radius:
                p["hp"] = max(0, p["hp"] - max(1, int(8 * dt)))
                if p["hp"] == 0:
                    p["alive"] = False
                    p["respawn_at"] = now + 5

        await broadcast(public_state())
        await asyncio.sleep(1 / TICK_RATE)

@app.on_event("startup")
async def startup():
    app.state.loop_task = asyncio.create_task(game_loop())

@app.on_event("shutdown")
async def shutdown():
    task = getattr(app.state, "loop_task", None)
    if task:
        task.cancel()

@app.get("/")
async def index():
    return FileResponse(STATIC_DIR / "index.html")

@app.get("/health")
async def health():
    return JSONResponse({"status": "ok", "players": len(players)})

async def handle_shot(shooter):
    if not shooter["alive"]:
        return
    sx, sz, yaw = shooter["x"], shooter["z"], shooter["yaw"]
    # Aim direction is derived from the player's facing angle.
    vx, vz = math.sin(yaw), -math.cos(yaw)
    candidates = []
    for target in players.values():
        if target["id"] == shooter["id"] or not target["alive"]:
            continue
        tx, tz = target["x"] - sx, target["z"] - sz
        distance = math.hypot(tx, tz)
        if distance > 18 or distance < 0.01:
            continue
        dot = (tx * vx + tz * vz) / distance
        if dot > 0.88:
            candidates.append((distance, target))
    if candidates:
        _, target = min(candidates, key=lambda item: item[0])
        target["hp"] = max(0, target["hp"] - 25)
        await broadcast({
            "type": "hit", "target": target["id"], "hp": target["hp"],
            "by": shooter["name"]
        })
        if target["hp"] == 0:
            target["alive"] = False
            target["respawn_at"] = time.monotonic() + 5
            await broadcast({"type": "message", "text": f'{target["name"]} was knocked out by {shooter["name"]}.'})

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    if len(players) >= MAX_PLAYERS:
        await ws.send_text(json.dumps({"type": "error", "message": "Arena is full. Try again shortly."}))
        await ws.close()
        return

    pid = secrets.token_urlsafe(8)
    name = safe_name(ws.query_params.get("name", "Player"))
    players[pid] = {
        "id": pid, "name": name,
        "x": secrets.randbelow(41) - 20,
        "z": secrets.randbelow(41) - 20,
        "yaw": 0.0, "hp": 100, "alive": True,
        "move": [0.0, 0.0], "respawn_at": 0.0
    }
    connections[pid] = ws

    await ws.send_text(json.dumps({"type": "welcome", "id": pid, "name": name}))
    await broadcast({"type": "message", "text": f"{name} joined the arena."})

    try:
        while True:
            data = await ws.receive_json()
            p = players.get(pid)
            if not p:
                break
            action = data.get("type")
            if action == "input":
                try:
                    mx = max(-1.0, min(1.0, float(data.get("x", 0))))
                    mz = max(-1.0, min(1.0, float(data.get("z", 0))))
                    yaw = float(data.get("yaw", 0))
                    if math.isfinite(yaw):
                        p["yaw"] = yaw
                    p["move"] = [mx, mz]
                except (TypeError, ValueError):
                    pass
            elif action == "shoot":
                await handle_shot(p)
            elif action == "respawn" and not p["alive"]:
                p["hp"] = 100
                p["alive"] = True
                p["x"] = secrets.randbelow(31) - 15
                p["z"] = secrets.randbelow(31) - 15
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        connections.pop(pid, None)
        players.pop(pid, None)
        await broadcast({"type": "message", "text": f"{name} left the arena."})
